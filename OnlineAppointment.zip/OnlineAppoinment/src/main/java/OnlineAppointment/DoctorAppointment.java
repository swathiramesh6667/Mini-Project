package OnlineAppointment;
import java.util.*;
public class DoctorAppointment 
{
	public static void main(String[] args) 
	{
ArrayList<String> al=new ArrayList<String>();
al.add(1, "Doctor");
al.add(2, "Patient");
al.add(3, "Admin");
al.add(4, "Exit");

System.out.println(al);
	}

}
